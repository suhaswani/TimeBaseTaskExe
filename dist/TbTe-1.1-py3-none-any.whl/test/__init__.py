import TbTe
